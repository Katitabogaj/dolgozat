import express from "express";
import carsRouter from "router";
import {initializeDB} from "./database.js";
import { readFile } from "fs/promises";

const app = express();


app.use(express.json());
app.use("/api/cars", carsRouter);

app.use((err,req,res,next) => {
    console.error(err.stack);
    res.status(500).json({message: err.message});
});

const startServer = async () =>{
    await initializeDB();
    app.listen(3001, () => console.log("A szerver a 3001-es porton fut."));
};

startServer();