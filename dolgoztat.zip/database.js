import sqlite3 from sqlite3;

const db = new sqlite3.Database("./sqlite_database");

const initializeDB = async () => {
    await db.Run("CREATE TABLE IF NOT EXISTS cars (id INTEGER PRIMARY KEY AUTOINCEREMENT, brand TEXT, model TEXT, color TEXT, year INTEGER)");

    const cars = [
        {
            brand: "Ferrari",
            model: "F40",
            color: "red",
            year: "1990"
        },
        {
            brand: "Ford",
            model: "Raptor",
            color: "black",
            year: "2023"
        },
        {
            brand: "Nissan",
            model: "370z",
            color: "dark blue",
            year: "2016"
        },
        {
            brand: "Mercedes-Benz",
            model: "G63 AMG",
            color: "white",
            year: "2024"
        },
    ]
};

function dbQuery(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, reject) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
}

function dbRun(sql, params =[]) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) reject(err); 
            else resolve(this);    
        });
    });
}

export {db, dbQuery, dbRun, initializeDB };