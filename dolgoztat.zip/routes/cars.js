import express from "express";
import { dbQuery, dbRun } from "../database";

const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const cars = await dbQuery("SELECT * FROM cars;");
  } catch (err) {
    next(err);
  }
});

router.get("/cars/:id", async (req, res, next) => {
  try {
    const [car] = await dbQuery("SELECT * FROM cars WHERE id = ?;");
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const result = await dbRun(
      "INSERT INTO cars (brand, model, color, year) VALUES (?, ?, ?, ?);",
      [req.body.brand, req.body.model, req.body.color, req.body.year]
    );
    res.status(201).json({ id: result.lastID, ...req.body });
  } catch (err) {
    next(err);
  }
});

router.put("/cars/:id", async (req, res, next) => {
  try {
    const [car] = await dbQuery("SELECT * FROM cars where id =?", [
      req.params.id,
    ]);
    if (!car) return res.status(404).json({ message: err.message });
    await dbRun(
      "UPDATE cars SET brand = ? , model = ?, color= ?, year =? WHERE id = ?;",
      [req.body.brand || car.brand, req.body.model || car.model, req.body.color || car.color, req.body.year || car.year, req.params.id]
    );
    res.status(200).json({ brand:req.body.brand || car.brand, model:req.body.model || car.model, color:req.body.color || car.color, year:req.body.year || car.year, id:req.params.id });
  } catch (err) {
    next(err);
  }
});

router.delete("/cars/:id", async (req, res, next) => {
    try {
      const [car] = await dbQuery("SELECT * FROM cars WHERE id = ?;");
    } catch (err) {
      next(err);
    }
  });
